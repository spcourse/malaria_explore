# Dataset description

> In total, Oregon State University’s Hatfield Marine Science Center has captured nearly 50 million plankton images over an 18-day period. This is more than 80 terabytes of data! They need your help creating an automated classification process to better understand the image contents.

~ [Description by National Data Science bowl](https://www.kaggle.com/competitions/datasciencebowl)

This is a subset of the original subset (😉) of labeled images of plankton from the first annual Data Science Bowl competition on Kaggle. Each folder represents a class. Images within the folder belong to that class.

For more information about this data, refer to the Kaggle page of [the first Data Science Bowl](https://www.kaggle.com/competitions/datasciencebowl).
